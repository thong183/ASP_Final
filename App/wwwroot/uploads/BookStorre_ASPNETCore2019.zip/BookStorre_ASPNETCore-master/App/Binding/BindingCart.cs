﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace App.Binding
{
    //{"UserId":"c71b54cf-18e6-1d7b-26ff-ac09d4b48609","TotalPrice":154,"TotalQuantity":14,"Cart":[{"Book_Id":1,"Quantity":14}]}
    public class BindingCart
    {
        public int UserId { get; set; }
        public int TotalPrice { get; set; }
        public int TotalQuantity { get; set; }
        public IEnumerable<BindingCartDetail> Cart { get; set; }
    }
    public class BindingCartDetail
    {
        public int Book_Id { get; set; }
        public int Quantity { get; set; }
    }
}
