﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using App.Data;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace App.Controllers.Apis
{
    [Route("api/[controller]")]
    [ApiController]
    public class CartController : ControllerBase
    {
        public DataContext _context;
        public CartController(DataContext context)
        {
            _context = context;
        }
        [HttpPost("Buy")]
        public async Task< IActionResult> Buy([FromBody] Binding.BindingCart cart)
        {
            var _cart = new Models.Cart(cart.UserId, cart.TotalPrice, cart.TotalQuantity);
            _context.Carts.Add(_cart);
            await _context.SaveChangesAsync();
            cart.Cart.ToList().ForEach(async x =>
            {
                var book = _context.Books.SingleOrDefault(y => y.Id == x.Book_Id);
                _context.CartDetails.Add(new Models.CartDetail()
                {
                    Book_Id = book.Id,
                    Cart_Id = _cart.Id,
                    Book_Price = book.Price,
                    Book_Saleoff = book.Saleoff,
                    Book_Title = book.Title,
                    Quantity = x.Quantity,
                    Total = x.Quantity * book.Price
                });

                await _context.SaveChangesAsync();
            });
            return Ok();
        }
    }
}