﻿
$(function () {
    window.cart = Init();
    UpdateIconCart()
})
function SaveToCart() {
    localStorage.setItem("cart", JSON.stringify(window.cart));
}
function ClearCart() {
    window.cart = [];
    localStorage.setItem("cart", JSON.stringify(window.cart));

    UpdateIconCart();
}
function cartData(id,name,price,quantity) {
    return { id: id, name: name, price: price, quantity: quantity}
}
function AddToCart(cartData) {
    var _item = GetFromCart(cartData.id);
    if (!_item) window.cart.push(cartData)
    else UpdateFormCart(cartData.id, cartData.quantity, false);

    SaveToCart();
    UpdateIconCart();
}
function GetFromCart(id) {
    return cart.find(x => x.id == id);
}
function UpdateFormCart(id, quantity,save = true) {
    var _ = GetFromCart(id);
    _.quantity += quantity;
    if (save) {
        SaveToCart();
        UpdateIconCart();
    }
}
function Init() {
    let _cart = localStorage.getItem("cart");
    _cart = JSON.parse(_cart);

    return _cart ? _cart: [];
}
function CountItem() {
    return window.cart.reduce((a, b) => a + Number(b.quantity), 0);
}
function UpdateIconCart() {
    document.querySelector("#itemCount").innerHTML = CountItem()
}